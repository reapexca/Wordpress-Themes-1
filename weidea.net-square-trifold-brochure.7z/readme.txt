Corporate Trifold Brochure Template.


1. First Select Horizontal Type Tool `T' in tool box.
2. Then double click the text layer & type your own data.
2. For Double Click on the smart objects show a new page.
3. Now Paste your Image and Resize it by pressing (Ctrl+T) & save it.
4. After finishing all of your edit. just save the file (Ctrl+S)


////////////////////// Now it's ready for print.//////////////////////
----------------------------------------------------------------------



Font Info :-

FONTS
Download free fonts used in this template

Roboto  : http://www.fontsquirrel.com/fonts/roboto
BEBAS-NEUE : https://www.fontsquirrel.com/fonts/bebas-neue/



Thanks for download Corporate Trifold Brochure..

FOLLOW ME ON GRAPHICRIVER :)

If you like my Item, please rate it :)
  