Thank you for choosing our product, do not forget to leave feedback and likes
if you liked everything, it's important to us, thank you.


-------------------- FONTS USED ------------------------

Montserrat
https://fonts.google.com/specimen/Montserrat


You can also use paid fonts if you bought them separately and want to use them in layouts.
You just need to add them to your collection and select in Photoshop.


-----------------------------------------------------------------------

www.evatheme.com - Your Creative Digital Store